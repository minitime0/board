from django.apps import AppConfig


class ArticleConfig(AppConfig):
    name = 'article'
